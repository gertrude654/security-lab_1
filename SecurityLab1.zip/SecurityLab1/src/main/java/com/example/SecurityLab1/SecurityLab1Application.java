package com.example.SecurityLab1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityLab1Application {

	public static void main(String[] args) {
		SpringApplication.run(SecurityLab1Application.class, args);
	}

}
